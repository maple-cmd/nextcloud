OC.L10N.register(
    "files_antivirus",
    {
    "Saved" : "Պահված",
    "TLS" : "TLS",
    "Select" : "Select",
    "Yes" : "Այո",
    "No" : "Ոչ",
    "Save" : "Պահպանել",
    "Description" : "Նկարագրություն"
},
"nplurals=2; plural=(n != 1);");
