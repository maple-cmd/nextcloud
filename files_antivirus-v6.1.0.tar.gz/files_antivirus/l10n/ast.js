OC.L10N.register(
    "files_antivirus",
    {
    "Unchecked" : "Desmarcóse",
    "Saving…" : "Guardando…",
    "Antivirus" : "Antivirus",
    "The file has been removed" : "Quitóse'l ficheru",
    "Saved" : "Guardóse",
    "Mode" : "Mou",
    "Host" : "Agospiador",
    "Port" : "Puertu",
    "TLS" : "TLS",
    "Select" : "Seleicionar",
    "bytes" : "bytes",
    "Delete file" : "Desaniciar el ficheru",
    "Yes" : "Sí",
    "No" : "Non",
    "Save" : "Guardar",
    "Description" : "Descripción"
},
"nplurals=2; plural=(n != 1);");
