OC.L10N.register(
    "files_antivirus",
    {
    "Saving…" : "Konservado...",
    "Saved" : "Konservita",
    "Host" : "Gastigo",
    "Port" : "Pordo",
    "TLS" : "TLS",
    "Select" : "Elekti",
    "Delete file" : "Forigi dosieron",
    "Yes" : "Jes",
    "No" : "Ne",
    "Save" : "Konservi",
    "Advanced" : "Progresinta",
    "Description" : "Priskribo"
},
"nplurals=2; plural=(n != 1);");
