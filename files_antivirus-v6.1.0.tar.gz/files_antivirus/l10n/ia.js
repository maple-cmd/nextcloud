OC.L10N.register(
    "files_antivirus",
    {
    "Saving…" : "Salveguardante...",
    "Saved" : "Salveguardate",
    "Host" : "Hospite",
    "Port" : "Porto",
    "Select" : "Selectionar",
    "Save" : "Salveguardar",
    "Description" : "Description"
},
"nplurals=2; plural=(n != 1);");
