OC.L10N.register(
    "files_antivirus",
    {
    "Saving…" : "Menyimpan...",
    "Saved" : "Disimpan",
    "Host" : "Host",
    "Port" : "Port",
    "TLS" : "TLS",
    "Select" : "Pilih",
    "Delete file" : "Hapus berkas",
    "Save" : "Simpan",
    "Advanced" : "Lanjutan",
    "Description" : "Deskrisi"
},
"nplurals=1; plural=0;");
