OC.L10N.register(
    "files_antivirus",
    {
    "Saving…" : "Saving…",
    "Saved" : "Saved",
    "Mode" : "Rejim",
    "Port" : "Port",
    "Select" : "Select",
    "Delete file" : "Delete file",
    "Yes" : "Ha",
    "No" : "Yo`q",
    "Save" : "Saqlash",
    "Description" : "Tavsif"
},
"nplurals=1; plural=0;");
