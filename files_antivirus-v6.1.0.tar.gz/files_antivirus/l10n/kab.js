OC.L10N.register(
    "files_antivirus",
    {
    "Select" : "Fren",
    "Delete file" : "Kkes afaylu",
    "Yes" : "Ih",
    "No" : "Uhu",
    "Save" : "Sekles",
    "Advanced" : "Talqayt",
    "Description" : "Aglam"
},
"nplurals=2; plural=(n != 1);");
