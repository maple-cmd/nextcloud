OC.L10N.register(
    "files_antivirus",
    {
    "Saving…" : "Enregistrament…",
    "Saved" : "Enregistrat",
    "Mode" : "Mòde",
    "Host" : "Òste",
    "Port" : "Pòrt",
    "Select" : "Select",
    "Delete file" : "Suprimir fichièr",
    "Yes" : "Òc",
    "No" : "Non",
    "Save" : "Salvar",
    "Description" : "Descripcion"
},
"nplurals=2; plural=(n > 1);");
