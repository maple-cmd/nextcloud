OC.L10N.register(
    "files_antivirus",
    {
    "Saved" : "﻿ಉಳಿಸಿದ",
    "Host" : "ಅತಿಥೆಯ-ಗಣಕ",
    "Port" : "﻿ರೇವು",
    "Select" : "Select",
    "Yes" : "﻿ಹೌದು",
    "No" : "﻿ಇಲ್ಲ",
    "Save" : "﻿ಉಳಿಸಿ"
},
"nplurals=2; plural=(n > 1);");
