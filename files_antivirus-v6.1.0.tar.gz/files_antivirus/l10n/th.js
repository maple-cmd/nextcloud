OC.L10N.register(
    "files_antivirus",
    {
    "Saved" : "บันทึกแล้ว",
    "Mode" : "โหมด",
    "Host" : "โฮสต์",
    "Port" : "พอร์ต",
    "TLS" : "TLS",
    "Select" : "เลือก",
    "Delete file" : "ลบไฟล์",
    "Yes" : "ใช่",
    "No" : "ไม่ตกลง",
    "Save" : "บันทึก",
    "Advanced" : "ขั้นสูง",
    "Description" : "คำอธิบาย"
},
"nplurals=1; plural=0;");
