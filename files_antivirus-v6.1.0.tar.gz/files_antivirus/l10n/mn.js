OC.L10N.register(
    "files_antivirus",
    {
    "Saving…" : "хадгалж байна",
    "Saved" : "Хадгалах",
    "Host" : "хост",
    "Port" : "порт",
    "Select" : "Сонгох",
    "Delete file" : "Файл устгах",
    "Save" : "Хадгалах",
    "Advanced" : "нарийвчилсан",
    "Description" : "Тодорхойлолт"
},
"nplurals=2; plural=(n != 1);");
