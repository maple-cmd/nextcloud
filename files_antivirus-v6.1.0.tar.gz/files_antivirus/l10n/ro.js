OC.L10N.register(
    "files_antivirus",
    {
    "Saving…" : "Se salvează...",
    "Saved" : "Salvat",
    "Mode" : "Mod",
    "Host" : "Gazdă",
    "Port" : "Portul",
    "TLS" : "TLS",
    "Select" : "Selectează",
    "Delete file" : "Șterge fișier",
    "Yes" : "Da",
    "No" : "Nu",
    "Save" : "Salvează",
    "Advanced" : "Avansat",
    "Description" : "Descriere"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
