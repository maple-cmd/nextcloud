<?php

/**
 * SPDX-FileCopyrightText: 2014 ownCloud, Inc.
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
$TRANSLATIONS = array(
"Save" => "Uložiť",
"Advanced" => "Pokročilé",
"Description" => "Popis"
);
$PLURAL_FORMS = "nplurals=3; plural=(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2;";
