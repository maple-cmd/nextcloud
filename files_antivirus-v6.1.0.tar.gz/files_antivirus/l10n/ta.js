OC.L10N.register(
    "files_antivirus",
    {
    "Host" : "ஓம்புனர்",
    "Port" : "துறை ",
    "Select" : "Select",
    "Yes" : "ஆம்",
    "No" : "இல்லை",
    "Save" : "சேமிக்க ",
    "Advanced" : "உயர்ந்த",
    "Description" : "விவரிப்பு"
},
"nplurals=2; plural=(n != 1);");
