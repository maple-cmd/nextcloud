OC.L10N.register(
    "files_antivirus",
    {
    "Antivirus" : "ප්‍රතිවයිරස",
    "The file has been removed" : "ගොනුව ඉවත් කර ඇත",
    "Antivirus for files" : "ගොනු සඳහා ප්‍රතිවයිරස",
    "Antivirus for Files" : "ගොනු සඳහා ප්‍රතිවයිරස",
    "Host" : " ධාරකය",
    "Select" : "තෝරන්න",
    "No" : "නැහැ",
    "Save" : "සුරකින්න",
    "Description" : "විස්තරය"
},
"nplurals=2; plural=(n != 1);");
