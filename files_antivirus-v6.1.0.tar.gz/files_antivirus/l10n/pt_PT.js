OC.L10N.register(
    "files_antivirus",
    {
    "Clean" : "Limpar",
    "Saving…" : "A guardar...",
    "Saved" : "Guardado",
    "Host" : "Anfitrião",
    "Address of Antivirus Host." : "Endereço do Anfitrião de Antivírus.",
    "Port" : "Porta",
    "Port number of Antivirus Host." : "Número da porta do Anfitrião de Antivírus.",
    "TLS" : "TLS",
    "Select" : "Selecionar",
    "bytes" : "bytes",
    "Delete file" : "Eliminar ficheiro",
    "Yes" : "Sim",
    "No" : "Não",
    "Save" : "Guardar",
    "Advanced" : "Avançado",
    "Description" : "Descrição"
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
