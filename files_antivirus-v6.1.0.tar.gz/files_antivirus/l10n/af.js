OC.L10N.register(
    "files_antivirus",
    {
    "Saving…" : "Bewaar…",
    "Saved" : "Bewaar",
    "Host" : "Gasheer",
    "Port" : "Poort",
    "Select" : "Kies",
    "Delete file" : "Skrap lêer",
    "Save" : "Stoor",
    "Advanced" : "Gevorderd",
    "Description" : "Beskrywing"
},
"nplurals=2; plural=(n != 1);");
