OC.L10N.register(
    "files_antivirus",
    {
    "Saving…" : "Guardando...",
    "Saved" : "Guardado",
    "Host" : "Servidor",
    "Port" : "Puerto",
    "Select" : "Seleccionar",
    "Delete file" : "Borrar archivo",
    "Save" : "Guardar",
    "Advanced" : "Avanzado",
    "Description" : "Descripción"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
