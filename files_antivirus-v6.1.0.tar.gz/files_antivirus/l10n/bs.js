OC.L10N.register(
    "files_antivirus",
    {
    "Saved" : "Spremljeno",
    "Port" : "Priključak",
    "TLS" : "TLS",
    "Select" : "Select",
    "Yes" : "Da",
    "No" : "Ne",
    "Save" : "Spremi",
    "Advanced" : "Napredno",
    "Description" : "Opis"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
