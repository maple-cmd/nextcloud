OC.L10N.register(
    "files_antivirus",
    {
    "Host" : "Host",
    "Port" : "Puerto",
    "Yes" : "Si",
    "No" : "No"
},
"nplurals=2; plural=(n != 1);");
