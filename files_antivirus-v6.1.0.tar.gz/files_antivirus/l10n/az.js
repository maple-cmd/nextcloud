OC.L10N.register(
    "files_antivirus",
    {
    "Saved" : "Saxlanıldı",
    "Host" : "Şəbəkədə ünvan",
    "Port" : "Port",
    "TLS" : "TLS",
    "Select" : "Select",
    "Yes" : "Bəli",
    "No" : "Xeyir",
    "Save" : "Saxla",
    "Advanced" : "İrəliləmiş",
    "Description" : "Açıqlanma"
},
"nplurals=2; plural=(n != 1);");
