OC.L10N.register(
    "files_antivirus",
    {
    "Saved" : "Lagra",
    "Host" : "Tenar",
    "Port" : "Port",
    "Select" : "Vel",
    "Delete file" : "Slett fil",
    "Save" : "Lagre",
    "Advanced" : "Avansert",
    "Description" : "Skildring"
},
"nplurals=2; plural=(n != 1);");
