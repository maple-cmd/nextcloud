OC.L10N.register(
    "files_antivirus",
    {
    "Saved" : "Disimpan",
    "Select" : "Select",
    "Yes" : "Ya",
    "No" : "Tidak",
    "Save" : "Simpan",
    "Advanced" : "Maju",
    "Description" : "Keterangan"
},
"nplurals=1; plural=0;");
