OC.L10N.register(
    "files_antivirus",
    {
    "Saved" : "Gespäichert",
    "Host" : "Host",
    "Port" : "Port",
    "Select" : "Select",
    "Yes" : "Jo",
    "No" : "Nee",
    "Save" : "Späicheren",
    "Advanced" : "Erweidert",
    "Description" : "Beschreiwung"
},
"nplurals=2; plural=(n != 1);");
