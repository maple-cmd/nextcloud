OC.L10N.register(
    "files_antivirus",
    {
    "Select" : "Select",
    "Yes" : "ہاں",
    "No" : "نہیں",
    "Save" : "حفظ",
    "Advanced" : "ایڈوانسڈ",
    "Description" : "تصریح"
},
"nplurals=2; plural=(n != 1);");
