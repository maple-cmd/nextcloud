OC.L10N.register(
    "files_antivirus",
    {
    "Select" : "ເລືອກ",
    "Delete file" : "ລຶບຟາຍ",
    "No" : "ບໍ່",
    "Save" : "ບັນທຶກ",
    "Advanced" : "ຂັ້ນສູງ"
},
"nplurals=1; plural=0;");
