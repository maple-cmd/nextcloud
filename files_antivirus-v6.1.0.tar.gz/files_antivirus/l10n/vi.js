OC.L10N.register(
    "files_antivirus",
    {
    "Saving…" : "Đang lưu...",
    "Saved" : "Đã lưu",
    "Mode" : "Chế độ",
    "Host" : "Máy chủ",
    "Port" : "Cổng",
    "Select" : "Chọn",
    "Delete file" : "Xóa tệp",
    "Yes" : "Có",
    "No" : "Không",
    "Save" : "Lưu",
    "Advanced" : "Nâng cao",
    "Description" : "Mô tả"
},
"nplurals=1; plural=0;");
