<?php

/**
 * SPDX-FileCopyrightText: 2013-2014 ownCloud, Inc.
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
$TRANSLATIONS = array(
"Save" => "tallentaa"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
