OC.L10N.register(
    "files_antivirus",
    {
    "Saving…" : "Saving…",
    "Saved" : "Saved",
    "Host" : "Host",
    "Port" : "Port",
    "Select" : "Select",
    "Delete file" : "Delete file",
    "Yes" : "კი",
    "No" : "არა",
    "Save" : "Save",
    "Advanced" : "Advanced",
    "Description" : "Description"
},
"nplurals=2; plural=(n!=1);");
