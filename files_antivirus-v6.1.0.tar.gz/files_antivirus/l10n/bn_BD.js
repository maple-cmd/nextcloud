OC.L10N.register(
    "files_antivirus",
    {
    "Saved" : "সংরক্ষণ করা হলো",
    "Host" : "হোস্ট",
    "Port" : "পোর্ট",
    "Select" : "সিলেক্ট",
    "Yes" : "হ্যাঁ",
    "No" : "না",
    "Save" : "সংরক্ষণ",
    "Advanced" : "সুচারু",
    "Description" : "বিবরণ"
},
"nplurals=2; plural=(n != 1);");
