OC.L10N.register(
    "files_antivirus",
    {
    "Saved" : "Wedi'u cadw",
    "Select" : "Select",
    "Yes" : "Ie",
    "No" : "Na",
    "Save" : "Cadw",
    "Advanced" : "Uwch",
    "Description" : "Disgrifiad"
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");
