OC.L10N.register(
    "files_antivirus",
    {
    "Saving…" : "Зачувува ...",
    "Saved" : "Зачувано",
    "Mode" : "Мод",
    "Host" : "Домаќин",
    "Port" : "Порта",
    "TLS" : "TLS",
    "Select" : "Select",
    "bytes" : "бајти",
    "Delete file" : "Избриши датотека",
    "Yes" : "Да",
    "No" : "Не",
    "Save" : "Зачувај",
    "Advanced" : "Напредно",
    "Description" : "Опис"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
