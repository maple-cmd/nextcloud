<?php
$appId = OCA\Mattermost\AppInfo\Application::APP_ID;
\OCP\Util::addScript($appId, $appId . '-personalSettings');
?>

<div id="mattermost_prefs"></div>
