<?php
$appId = OCA\Mattermost\AppInfo\Application::APP_ID;
\OCP\Util::addScript($appId, $appId . '-adminSettings');
?>

<div id="mattermost_prefs"></div>
