OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Login",
    "Password" : "Kata laluan",
    "Edit" : "Sunting",
    "Files" : "Fail",
    "Type" : "Jenis",
    "Cancel" : "Batal",
    "Connect" : "Berhubung"
},
"nplurals=1; plural=0;");
