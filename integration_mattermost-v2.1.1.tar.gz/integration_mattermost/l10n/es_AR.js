OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Inicio de sesión",
    "Password" : "Contraseña",
    "View only" : "Solo ver",
    "Edit" : "Editar",
    "Files" : "Archivos",
    "Type" : "Escribir",
    "Set expiration date" : "Establecer fecha de caducidad",
    "Comment" : "Comentario",
    "Cancel" : "Cancelar",
    "Connect" : "Conectar",
    "Upload files" : "Subiendo archivos"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
