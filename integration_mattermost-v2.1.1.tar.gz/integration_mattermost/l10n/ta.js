OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Login",
    "Password" : "கடவுச்சொல்",
    "Edit" : "தொகுக்க",
    "Files" : "கோப்புகள்",
    "Type" : "வகை",
    "Set expiration date" : "காலாவதி தேதியை குறிப்பிடுக",
    "Cancel" : "இரத்து செய்க",
    "Connect" : "இணைக்க"
},
"nplurals=2; plural=(n != 1);");
