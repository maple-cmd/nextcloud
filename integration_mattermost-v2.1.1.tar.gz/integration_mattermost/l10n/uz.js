OC.L10N.register(
    "integration_mattermost",
    {
    "Bad credentials" : "Akkaunt ma'lumotlari xato",
    "Bad HTTP method" : "Yomon HTTP usuli",
    "Personal access token" : "Shaxsiy kirish belgisi",
    "Login" : "Login",
    "Password" : "Password",
    "Edit" : "Tahrirlash",
    "Files" : "Files",
    "Type" : "Turi",
    "Set expiration date" : "Set expiration date",
    "Comment" : "Izoh",
    "Cancel" : "Cancel",
    "Connect" : "Connect"
},
"nplurals=1; plural=0;");
