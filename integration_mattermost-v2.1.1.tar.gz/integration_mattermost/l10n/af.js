OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Teken aan",
    "Password" : "Wagwoord",
    "Edit" : "Wysig",
    "Files" : " Lêers",
    "Type" : "Tipe",
    "Set expiration date" : "Stel vervaldatum",
    "Comment" : "Kommentaar",
    "Cancel" : "Kanselleer",
    "Connect" : "Verbind",
    "Upload files" : "Laai lêers op"
},
"nplurals=2; plural=(n != 1);");
