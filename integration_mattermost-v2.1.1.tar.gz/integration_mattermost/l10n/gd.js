OC.L10N.register(
    "integration_mattermost",
    {
    "Password" : "Facal-faire",
    "Edit" : "Deasaich",
    "Files" : "Faidhlichean",
    "Type" : "Seòrsa",
    "Set expiration date" : "Suidhich gum falbh an ùine air",
    "Cancel" : "Sguir dheth",
    "Upload files" : "Luchdaich suas faidhlichean"
},
"nplurals=4; plural=(n==1 || n==11) ? 0 : (n==2 || n==12) ? 1 : (n > 2 && n < 20) ? 2 : 3;");
