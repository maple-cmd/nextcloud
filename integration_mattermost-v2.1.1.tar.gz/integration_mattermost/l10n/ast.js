OC.L10N.register(
    "integration_mattermost",
    {
    "Failed to save Mattermost options" : "Nun se puen guardar les opciones de Mattermost",
    "Login" : "Aniciar la sesión",
    "Password" : "Contraseña",
    "View only" : "Ver namás",
    "Edit" : "Editar",
    "Failed to load Mattermost channels" : "Nun se puen cargar les canales de Mattermost",
    "Files" : "Ficheros",
    "Channel" : "Canal",
    "Type" : "Tipu",
    "Set expiration date" : "Afitar la data de caducidá",
    "Comment" : "Comentariu",
    "Cancel" : "Encaboxar",
    "Failed to get Mattermost notifications" : "Nun se puen consiguir los avisos de Mattermost",
    "Failed to send links to Mattermost" : "Nun se puen unviar los avisos a Mattermost",
    "Failed to send internal links to Mattermost" : "Nun se puen unviar los enllaces internos a Mattermost",
    "Failed to send files to Mattermost" : "Nun se puen unviar los ficheros a Mattermost",
    "Connect" : "Coneutar"
},
"nplurals=2; plural=(n != 1);");
