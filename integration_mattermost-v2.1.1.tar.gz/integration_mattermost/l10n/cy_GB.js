OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Login",
    "Password" : "Cyfrinair",
    "Edit" : "Golygu",
    "Files" : "Ffeiliau",
    "Type" : "Math",
    "Set expiration date" : "Gosod dyddiad dod i ben",
    "Comment" : "Sylw",
    "Cancel" : "Diddymu",
    "Connect" : "Cysylltu"
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");
