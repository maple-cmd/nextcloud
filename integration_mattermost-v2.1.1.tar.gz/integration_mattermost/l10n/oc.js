OC.L10N.register(
    "integration_mattermost",
    {
    "Bad credentials" : "Marrits identificants",
    "Connected accounts" : "Comptes connectats",
    "Login" : "Login",
    "Password" : "Senhal",
    "Connected as {user}" : "Connectat coma {user}",
    "View only" : "Veire solament",
    "Edit" : "Modificar",
    "Files" : "Fichièrs",
    "Channel" : "Cadena",
    "Type" : "Tipe",
    "Set expiration date" : "Especificar una data d'expiracion",
    "Comment" : "Comentaris",
    "Cancel" : "Anullar",
    "Connect" : "Connectar"
},
"nplurals=2; plural=(n > 1);");
