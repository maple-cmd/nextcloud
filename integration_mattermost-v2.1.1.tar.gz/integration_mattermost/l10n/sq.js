OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Hyrje",
    "Password" : "Fjalëkalim",
    "Edit" : "Përpuno",
    "Files" : "Skedarët",
    "Type" : "Shtyp",
    "Set expiration date" : "Caktoni datë skadimi",
    "Comment" : "Koment",
    "Cancel" : "Anullo",
    "Connect" : "Lidhu",
    "Upload files" : "Ngarko skedarët"
},
"nplurals=2; plural=(n != 1);");
