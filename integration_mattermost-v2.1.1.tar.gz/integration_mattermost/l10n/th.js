OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "เข้าสู่ระบบ",
    "Password" : "รหัสผ่าน",
    "Connected as {user}" : "เชื่อมต่อเป็น {user} แล้ว",
    "password" : "รหัสผ่าน",
    "View only" : "ดูเท่านั้น",
    "Edit" : "แก้ไข",
    "Files" : "ไฟล์",
    "Type" : "ประเภท",
    "Set expiration date" : "กำหนดวันหมดอายุ",
    "Comment" : "ความคิดเห็น",
    "Cancel" : "ยกเลิก",
    "_Send file_::_Send files_" : ["ส่งไฟล์"],
    "_Send link_::_Send links_" : ["ส่งลิงค์"],
    "Connect" : "เชื่อมต่อ",
    "Upload files" : "อัพโหลดไฟล์จากเครื่อง"
},
"nplurals=1; plural=0;");
