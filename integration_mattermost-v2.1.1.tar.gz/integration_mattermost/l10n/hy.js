OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Login",
    "Password" : "Գաղտնաբառ",
    "Edit" : "մշակել",
    "Files" : "Ֆայլեր",
    "Type" : "Տիպ",
    "Set expiration date" : "Սահմանել վավերականության ժամկետ",
    "Comment" : "Մեկնաբանել",
    "Cancel" : "ընդհատել",
    "Connect" : "միացնել"
},
"nplurals=2; plural=(n != 1);");
