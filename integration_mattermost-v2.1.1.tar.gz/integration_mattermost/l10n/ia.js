OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Login",
    "Password" : "Contrasigno",
    "Edit" : "Modificar",
    "Files" : "Files",
    "Type" : "Typo",
    "Set expiration date" : "Assignar data de expiration",
    "Comment" : "Commentario",
    "Cancel" : "Cancellar",
    "Connect" : "Connecter se"
},
"nplurals=2; plural=(n != 1);");
