OC.L10N.register(
    "integration_mattermost",
    {
    "Password" : "ລະຫັດຜ່ານ",
    "Edit" : "ແກ້ໄຂ",
    "Files" : "ຟາຍ",
    "Type" : "ພິມ",
    "Set expiration date" : "ກໍານົດວັນໝົດອາຍຸ",
    "Cancel" : "ຍົກເລີກ",
    "Upload files" : "ອັບໂຫຼດຟາຍ"
},
"nplurals=1; plural=0;");
