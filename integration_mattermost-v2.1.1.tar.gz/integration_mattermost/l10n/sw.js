OC.L10N.register(
    "integration_mattermost",
    {
    "Error during OAuth exchanges" : "Hitilafu wakati wa kubadilishana OAuth",
    "Bad credentials" : "Sifa mbaya",
    "Bad HTTP method" : "Njia mbaya ya HTTP ",
    "OAuth access token refused" : "Ufikiaji wa token za OAuth umekataliwa",
    "Connected accounts" : "Akaunti zilizounganishwa",
    "Make sure you set the \"Redirect URI\" to" : "Make sure you set the \"Redirect URI\" to",
    "Use a popup to authenticate" : "Tumia dirisha ibukizi ili kuthibitisha",
    "Login" : "Ingia",
    "Password" : "Nenosiri",
    "Connected as {user}" : "Imeunganishwa kama {user}",
    "Edit" : "Hariri",
    "Files" : "Mafaili",
    "Type" : "Aina",
    "Set expiration date" : "Panga tarehe ya mwisho wa matumizi",
    "Comment" : "Maoni",
    "Cancel" : "Cancel"
},
"nplurals=2; plural=(n != 1);");
