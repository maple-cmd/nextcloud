OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Aseqdac",
    "Password" : "Awal uffir",
    "Edit" : "Ẓreg",
    "Files" : "Ifuyla",
    "Type" : "Anaw",
    "Comment" : "Commentaire",
    "Cancel" : "Sefsex",
    "Upload files" : "Azen ifuyla"
},
"nplurals=2; plural=(n != 1);");
