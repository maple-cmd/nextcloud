OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Login",
    "Password" : "ពាក្យសម្ងាត់",
    "Edit" : "កែប្រែ",
    "Files" : "ឯកសារ",
    "Type" : "ប្រភេទ",
    "Set expiration date" : "កំណត់​ពេល​ផុត​កំណត់",
    "Comment" : "មតិ",
    "Cancel" : "បោះបង់",
    "Connect" : "ភ្ជាប់"
},
"nplurals=1; plural=0;");
