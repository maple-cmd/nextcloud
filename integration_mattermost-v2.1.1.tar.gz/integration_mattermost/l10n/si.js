OC.L10N.register(
    "integration_mattermost",
    {
    "Connected accounts" : "සම්බන්ධිත ගිණුම්",
    "Login" : "පිවිසෙන්න",
    "Password" : "මුර පදය",
    "Edit" : "සංස්කරණය",
    "Files" : "ගොනු",
    "Comment" : "අදහස",
    "Cancel" : "අවලංගු කරන්න",
    "Connect" : "සම්බන්ධ කරන්න",
    "Upload files" : "ගොනු උඩුගත කරන්න"
},
"nplurals=2; plural=(n != 1);");
