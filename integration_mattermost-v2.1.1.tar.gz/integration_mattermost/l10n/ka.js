OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Login",
    "Password" : "პაროლი",
    "View only" : "View only",
    "Edit" : "Edit",
    "Files" : "ფაილები",
    "Channel" : "Channel",
    "Type" : "Type",
    "Set expiration date" : "Set expiration date",
    "Comment" : "Comment",
    "Cancel" : "Cancel",
    "Connect" : "Connect",
    "Upload files" : "Upload files"
},
"nplurals=2; plural=(n!=1);");
