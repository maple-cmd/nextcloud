OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Iniciar sesión",
    "Password" : "Contraseña",
    "View only" : "Sólo lectura",
    "Edit" : "Editar",
    "Files" : "Archivos",
    "Type" : "Tipo",
    "Set expiration date" : "Establece la fecha de expiración",
    "Comment" : "Comentario",
    "Cancel" : "Cancelar",
    "Connect" : "Conectar",
    "Upload files" : "Cargar archivos"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
