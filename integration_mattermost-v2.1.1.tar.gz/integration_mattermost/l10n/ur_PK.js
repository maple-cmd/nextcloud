OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Login",
    "Password" : "پاسورڈ",
    "Edit" : "تدوین کریں",
    "Type" : "Type",
    "Set expiration date" : "تاریخ معیاد سیٹ کریں",
    "Cancel" : "منسوخ کریں",
    "Connect" : "منسلک"
},
"nplurals=2; plural=(n != 1);");
