OC.L10N.register(
    "integration_mattermost",
    {
    "Connected accounts" : "Tilkopla kontoar",
    "Application ID" : "Program-ID",
    "Login" : "Login",
    "Password" : "Passord",
    "Edit" : "Rediger",
    "Files" : "Filer",
    "Type" : "Type",
    "Set expiration date" : "Set utløpsdato",
    "Comment" : "Kommentér",
    "Cancel" : "Avbryt",
    "Connect" : "Kople til",
    "Upload files" : "Last opp filar"
},
"nplurals=2; plural=(n != 1);");
