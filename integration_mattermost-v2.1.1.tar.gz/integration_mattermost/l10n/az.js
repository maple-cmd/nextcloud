OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Login",
    "Password" : "Şifrə",
    "Edit" : "Dəyişiklik et",
    "Files" : "Fayllar",
    "Type" : "Type",
    "Comment" : "Komentariya",
    "Cancel" : "Dayandır",
    "Connect" : "Qoşul"
},
"nplurals=2; plural=(n != 1);");
