OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "ავტორიზაცია",
    "Password" : "პაროლი",
    "Edit" : "შეცვლა",
    "Files" : "ფაილები",
    "Type" : "სახეობა",
    "Set expiration date" : "მიუთითეთ ვადის გასვლის დრო",
    "Comment" : "კომენტარი",
    "Cancel" : "უარყოფა",
    "Connect" : "დაკავშირება",
    "Upload files" : "ფაილების ატვირთვა"
},
"nplurals=2; plural=(n!=1);");
