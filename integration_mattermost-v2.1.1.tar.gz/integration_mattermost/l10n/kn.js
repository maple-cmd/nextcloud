OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Login",
    "Password" : "ಗುಪ್ತ ಪದ",
    "Edit" : "ಸಂಪಾದಿಸು",
    "Files" : "ಕಡತಗಳು",
    "Type" : "Type",
    "Set expiration date" : "ಮುಕ್ತಾಯ ದಿನಾಂಕವನ್ನು ನಿರ್ದರಿಸಿ",
    "Cancel" : "﻿ರದ್ದು"
},
"nplurals=2; plural=(n > 1);");
