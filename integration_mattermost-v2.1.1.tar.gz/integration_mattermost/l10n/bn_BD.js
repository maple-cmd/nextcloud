OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Login",
    "Password" : "কূটশব্দ",
    "Edit" : "সম্পাদনা",
    "Files" : "ফাইল",
    "Type" : "ধরণ",
    "Set expiration date" : "মেয়াদোত্তীর্ণ হওয়ার তারিখ নির্ধারণ করুন",
    "Comment" : "মন্তব্য",
    "Cancel" : "বাতির",
    "Connect" : "সংযুক্ত হও"
},
"nplurals=2; plural=(n != 1);");
