OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Login",
    "Password" : "Pasvorto",
    "Edit" : "Modifi",
    "Files" : "Dosieroj",
    "Type" : "Tipo",
    "Set expiration date" : "Uzi limdaton",
    "Comment" : "Komento",
    "Cancel" : "Nuligi",
    "Connect" : "Konekti",
    "Upload files" : "Alŝuti dosierojn"
},
"nplurals=2; plural=(n != 1);");
