OC.L10N.register(
    "integration_mattermost",
    {
    "Login" : "Login",
    "Password" : "Passwuert",
    "Edit" : "Änneren",
    "Files" : "Fichieren",
    "Type" : "Typ",
    "Set expiration date" : "Verfallsdatum setzen",
    "Comment" : "Kommentar",
    "Cancel" : "Ofbriechen",
    "Connect" : "Verbannen"
},
"nplurals=2; plural=(n != 1);");
