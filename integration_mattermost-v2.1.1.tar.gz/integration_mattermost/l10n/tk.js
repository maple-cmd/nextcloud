OC.L10N.register(
    "integration_mattermost",
    {
    "Password" : "Açarsöz",
    "Edit" : "Redaktirläň",
    "Files" : "Faýllar",
    "Type" : "Görnüşi",
    "Set expiration date" : "Möhlet möhletini belläň",
    "Cancel" : "ýatyrmak",
    "Upload files" : "Faýllary ýükläň"
},
"nplurals=2; plural=(n != 1);");
