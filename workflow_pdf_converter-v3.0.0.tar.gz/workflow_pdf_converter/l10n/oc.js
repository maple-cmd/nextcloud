OC.L10N.register(
    "workflow_pdf_converter",
    {
    "Please choose a mode." : "Mercés de causir un mòde.",
    "PDF conversion" : "Conversion PDF",
    "Automated PDF conversion" : "Conversion PDF automatica",
    "Keep original, preserve existing PDFs" : "Gardar l’original, servar los PDF existents",
    "Keep original, overwrite existing PDF" : "Gardar l’original, remplaçar los PDF existents",
    "Delete original, preserve existing PDFs" : "Suprimir l’original, servar los PDF existents",
    "Delete original, overwrite existing PDF" : "Suprimir l’original, remplaçar los PDF existents"
},
"nplurals=2; plural=(n > 1);");
