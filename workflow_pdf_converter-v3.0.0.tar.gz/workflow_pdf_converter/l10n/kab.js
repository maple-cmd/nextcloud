OC.L10N.register(
    "workflow_pdf_converter",
    {
    "Please choose a mode." : "Ttxil-k fren askar.",
    "PDF conversion" : "Aselket PDF"
},
"nplurals=2; plural=(n != 1);");
