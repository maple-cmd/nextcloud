OC.L10N.register(
    "workflow_pdf_converter",
    {
    "Please choose a mode." : "Escueyi un mou",
    "PDF conversion" : "Conversión de PDF",
    "Convert documents into the PDF format on upload and write." : "Convierte documentos nel formatu PDF al xubir y escribir.",
    "Automated PDF conversion" : "Conversión de PDFs automatizada",
    "Delete original, preserve existing PDFs" : "Desaniciar los orixinales, caltener los PDFs orixinales",
    "Delete original, overwrite existing PDF" : "Desaniciar l'orixinal, caltener el PDF orixinal"
},
"nplurals=2; plural=(n != 1);");
