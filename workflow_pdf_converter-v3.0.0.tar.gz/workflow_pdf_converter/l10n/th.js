OC.L10N.register(
    "workflow_pdf_converter",
    {
    "Please choose a mode." : "โปรดเลือกโหมด",
    "PDF conversion" : "การแปลง PDF",
    "Automated PDF conversion" : "แปลงเอกสาร PDF อัตโนมัติ"
},
"nplurals=1; plural=0;");
