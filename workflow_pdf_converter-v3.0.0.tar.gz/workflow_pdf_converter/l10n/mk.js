OC.L10N.register(
    "workflow_pdf_converter",
    {
    "Please choose a mode." : "Изберете мод.",
    "PDF conversion" : "PDF конверзија",
    "Keep original, preserve existing PDFs" : "Зачувај ги оргиналните, зачувај ги постоечките PDF датотеки",
    "Keep original, overwrite existing PDF" : "Зачувај ги оргиналните, преклопи ги постоечките PDF датотеки",
    "Delete original, preserve existing PDFs" : "Избриши ги оргиналните, зачувај ги постоечките PDF датотеки",
    "Delete original, overwrite existing PDF" : "Избриши ги оргиналните, преклопи ги постоечките PDF датотеки"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
