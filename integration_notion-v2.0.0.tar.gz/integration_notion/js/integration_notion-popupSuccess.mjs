import{l as n}from"./index-Dl858C8_.chunk.mjs";const o=n("integration_notion","popup-data"),e=o.user_name,s=o.user_id;window.opener&&(window.opener.postMessage({userName:e,userId:s}),window.close());
//# sourceMappingURL=integration_notion-popupSuccess.mjs.map
