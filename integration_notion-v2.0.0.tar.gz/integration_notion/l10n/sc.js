OC.L10N.register(
    "integration_notion",
    {
    "Error getting OAuth access token. " : "Errore otenende token de intrada OAuth.",
    "Error during OAuth exchanges" : "Errore cuncambiende OAuth",
    "Bad HTTP method" : "Mètodu HTTP no bàlidu",
    "Bad credentials" : "Credentziales non bàlidas",
    "OAuth access token refused" : "Token de intrada OAuth refudadu",
    "Connected accounts" : "Contos connètidos",
    "Make sure you set the \"Redirect URI\" to" : "Assegura·ti de cunfigurare s'\"URI de ri-aderetada\" comente",
    "Application ID" : "ID aplicatzione",
    "Application secret" : "Segretu de s'aplicatzione",
    "Connected as {user}" : "Connètidu comente {user}",
    "Connect" : "Connete",
    "Cancel" : "Cancel"
},
"nplurals=2; plural=(n != 1);");
