OC.L10N.register(
    "integration_notion",
    {
    "Bad credentials" : "Marrits identificants",
    "Connected accounts" : "Comptes connectats",
    "Connected as {user}" : "Connectat coma {user}",
    "Connect" : "Connectar",
    "Cancel" : "Cancel"
},
"nplurals=2; plural=(n > 1);");
