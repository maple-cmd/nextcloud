OC.L10N.register(
    "integration_notion",
    {
    "Error during OAuth exchanges" : "Грешка при размена на податоци со OAuth ",
    "Bad credentials" : "Неточни акредитиви",
    "OAuth access token refused" : "Одбиен OAuth пристапен токен ",
    "Connected accounts" : "Поврзани сметки",
    "Make sure you set the \"Redirect URI\" to" : "И бидете сигурни дека сте ја поставиле \"Redirect URI\" во",
    "Use a popup to authenticate" : "користи скокачки прозор за автентификација",
    "Connected as {user}" : "Поврзан како {user}",
    "Connect" : "Поврзи се",
    "Cancel" : "Cancel"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
