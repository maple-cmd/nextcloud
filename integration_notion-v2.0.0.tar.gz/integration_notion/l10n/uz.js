OC.L10N.register(
    "integration_notion",
    {
    "Bad HTTP method" : "Yomon HTTP usuli",
    "Bad credentials" : "Akkaunt ma'lumotlari xato",
    "Connected accounts" : "Ulangan akkauntlar",
    "Connect" : "Connect",
    "Cancel" : "Bekor qilish"
},
"nplurals=1; plural=0;");
