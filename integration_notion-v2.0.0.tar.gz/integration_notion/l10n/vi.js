OC.L10N.register(
    "integration_notion",
    {
    "Bad HTTP method" : "Phương thức HTTP không hợp lệ",
    "Bad credentials" : "Thông tin đăng nhập không hợp lệ.",
    "Connected accounts" : "Đã kết nối tài khoản",
    "Connected as {user}" : "Kết nối bởi {user}",
    "Connect" : "Kết nối",
    "Cancel" : "Cancel"
},
"nplurals=1; plural=0;");
