OC.L10N.register(
    "integration_notion",
    {
    "Error during OAuth exchanges" : "Villa í OAuth-samskiptum",
    "Bad credentials" : "Gölluð auðkenni",
    "OAuth access token refused" : "OAuth-aðgangsteikni hafnað",
    "Connected accounts" : "Tengdir aðgangar",
    "Connected as {user}" : "Tengt sem {user}",
    "Connect" : "Tengjast",
    "Cancel" : "Cancel"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
