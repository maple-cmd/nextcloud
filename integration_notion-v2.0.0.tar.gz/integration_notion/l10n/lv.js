OC.L10N.register(
    "integration_notion",
    {
    "Bad HTTP method" : "Nederīgs HTTP pieprasījuma veids",
    "Bad credentials" : "Nederīgi pieteikšanās dati",
    "Connected accounts" : "Sasaistītie konti",
    "Application ID" : "Lietotnes Id",
    "Application secret" : "Lietotnes noslēpums",
    "Connected as {user}" : "Savienojies kā {user}",
    "Connect" : "Savienoties",
    "Cancel" : "Atcelt"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
