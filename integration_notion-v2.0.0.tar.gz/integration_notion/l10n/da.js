OC.L10N.register(
    "integration_notion",
    {
    "Error getting OAuth access token. " : "Fejl ved anmodning om OAuth adgangsnøgle",
    "Error during OAuth exchanges" : "Fejl under OAuth-udvekslinger",
    "Bad HTTP method" : "Dårlig HTTP metode",
    "Bad credentials" : "Forkerte legitimationsoplysninger",
    "OAuth access token refused" : "OAuth adgangsnøgle afvist",
    "Connected accounts" : "Forbundne konti",
    "Connected as {user}" : "Forbundet som {user}",
    "Connect" : "Tilslut",
    "Cancel" : "Annullér"
},
"nplurals=2; plural=(n != 1);");
