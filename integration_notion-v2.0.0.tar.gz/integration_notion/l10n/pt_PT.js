OC.L10N.register(
    "integration_notion",
    {
    "Error during OAuth exchanges" : "Erro durante trocas com o OAuth",
    "Bad HTTP method" : "Método HTTP incorreto",
    "Bad credentials" : "Credenciais inválidas",
    "Connect" : "Ligar",
    "Cancel" : "Cancel"
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
