OC.L10N.register(
    "integration_notion",
    {
    "Connected accounts" : "සම්බන්ධිත ගිණුම්",
    "Connect" : "සම්බන්ධ කරන්න",
    "Cancel" : "Cancel"
},
"nplurals=2; plural=(n != 1);");
