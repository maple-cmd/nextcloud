OC.L10N.register(
    "integration_notion",
    {
    "Connected accounts" : "Tilkopla kontoar",
    "Application ID" : "Program-ID",
    "Connect" : "Kople til",
    "Cancel" : "Cancel"
},
"nplurals=2; plural=(n != 1);");
