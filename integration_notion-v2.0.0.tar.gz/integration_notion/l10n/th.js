OC.L10N.register(
    "integration_notion",
    {
    "Connected as {user}" : "เชื่อมต่อเป็น {user} แล้ว",
    "Connect" : "เชื่อมต่อ",
    "Cancel" : "Cancel"
},
"nplurals=1; plural=0;");
