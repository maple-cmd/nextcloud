OC.L10N.register(
    "integration_notion",
    {
    "Error during OAuth exchanges" : "OAuth 교환 중 오류 발생",
    "Bad HTTP method" : "옳지 않은 HTTP 메소드",
    "Bad credentials" : "옳지 않은 자격 증명",
    "OAuth access token refused" : "OAuth 접근 토큰 거부됨",
    "Connected accounts" : "계정 연결됨",
    "Application ID" : "애플리케이션 ID",
    "Connected as {user}" : "{user}로 연결됨",
    "Connect" : "연결",
    "Cancel" : "Cancel"
},
"nplurals=1; plural=0;");
