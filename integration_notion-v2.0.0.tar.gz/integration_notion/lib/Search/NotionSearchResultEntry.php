<?php

/**
 * SPDX-FileCopyrightText: 2020 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */

declare(strict_types=1);

namespace OCA\Notion\Search;

use OCP\Search\SearchResultEntry;

class NotionSearchResultEntry extends SearchResultEntry {
}
