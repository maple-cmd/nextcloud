# Authors

* Julien Veyssier <julien-nc@posteo.net> (Developper)
* Sami Finnilä <sami.finnila@nextcloud.com> (Secondary developer)
