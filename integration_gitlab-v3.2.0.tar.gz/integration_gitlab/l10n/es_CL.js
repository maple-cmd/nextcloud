OC.L10N.register(
    "integration_gitlab",
    {
    "Remove account" : "Cerrar sesión",
    "Unknown error" : "Se presentó un error desconocido",
    "Comments" : "Comentarios",
    "Owner" : "Dueño"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
