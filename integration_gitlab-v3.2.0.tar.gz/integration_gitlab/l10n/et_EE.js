OC.L10N.register(
    "integration_gitlab",
    {
    "Bad HTTP method" : "Vigane HTTP-meetod",
    "Bad credentials" : "Vale kasutajanimi, salasõna või tunnusluba",
    "Connected accounts" : "Ühendatud kasutajakontod",
    "Instance address" : "Serveri aadress",
    "Personal access token" : "Isiklik tunnusluba ligipääsuks",
    "Gitlab Account for Dashboard widget" : "Gitlabi kasutajakonto for Juhtpaneeli vidina jaoks",
    "Unknown error" : "Tundmatu viga",
    "by {creator}" : "kasutajalt {creator}",
    "Comments" : "Kommentaarid",
    "Author" : "Autor",
    "Owner" : "Omanik"
},
"nplurals=2; plural=(n != 1);");
