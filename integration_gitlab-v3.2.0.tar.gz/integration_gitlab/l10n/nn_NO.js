OC.L10N.register(
    "integration_gitlab",
    {
    "Connected accounts" : "Tilkopla kontoar",
    "Application ID" : "Program-ID",
    "Unknown error" : "Ukjend feil",
    "Comments" : "Kommentarar",
    "Owner" : "Owner"
},
"nplurals=2; plural=(n != 1);");
