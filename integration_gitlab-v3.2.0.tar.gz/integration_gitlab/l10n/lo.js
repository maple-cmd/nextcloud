OC.L10N.register(
    "integration_gitlab",
    {
    "Remove account" : "ຍ້າຍບັນຊີ",
    "Unknown error" : "ຜິດພາດທີ່ບໍ່ຮູ້ຈັກ",
    "Comments" : "ຄໍາເຫັນ",
    "Owner" : "ເຈົ້າຂອງ"
},
"nplurals=1; plural=0;");
