OC.L10N.register(
    "integration_gitlab",
    {
    "Remove account" : "Hiqe llogarinë",
    "Unknown error" : "Gabim i panjohur",
    "Comments" : "Komentet",
    "Owner" : "Zotëruesi"
},
"nplurals=2; plural=(n != 1);");
