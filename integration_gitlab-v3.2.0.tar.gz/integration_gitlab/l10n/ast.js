OC.L10N.register(
    "integration_gitlab",
    {
    "Failed to save GitLab options" : "Nun se puen guardar les opciones de GitLab",
    "Remove account" : "Quitar la cuenta",
    "Unknown error" : "Error desconocíu",
    "Comments" : "Comentarios",
    "Author" : "Autoría",
    "Owner" : "Propietariu"
},
"nplurals=2; plural=(n != 1);");
