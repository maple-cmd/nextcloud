OC.L10N.register(
    "integration_gitlab",
    {
    "Remove account" : "Remove account",
    "Unknown error" : "Unknown error",
    "Comments" : "Comments",
    "Author" : "Author",
    "Owner" : "Owner",
    "Click to expand comment" : "Click to expand comment"
},
"nplurals=2; plural=(n!=1);");
