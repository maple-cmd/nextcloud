OC.L10N.register(
    "integration_gitlab",
    {
    "Bad HTTP method" : "Yomon HTTP usuli",
    "Bad credentials" : "Akkaunt ma'lumotlari xato",
    "Personal access token" : "Shaxsiy kirish belgisi",
    "Unknown error" : "Unknown error",
    "Comments" : "Comments",
    "Owner" : "Owner"
},
"nplurals=1; plural=0;");
