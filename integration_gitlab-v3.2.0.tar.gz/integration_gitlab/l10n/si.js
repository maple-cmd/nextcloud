OC.L10N.register(
    "integration_gitlab",
    {
    "Connected accounts" : "සම්බන්ධිත ගිණුම්",
    "Unknown error" : "නොදන්නා දෝෂයකි",
    "Comments" : "අදහස්",
    "Owner" : "හිමිකරු"
},
"nplurals=2; plural=(n != 1);");
