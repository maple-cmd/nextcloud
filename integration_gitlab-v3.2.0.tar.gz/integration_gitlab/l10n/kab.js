OC.L10N.register(
    "integration_gitlab",
    {
    "Remove account" : "Kkes amiḍan",
    "Unknown error" : "Erreur inconnue",
    "Comments" : "Commentaires",
    "Owner" : "Bab"
},
"nplurals=2; plural=(n != 1);");
