OC.L10N.register(
    "integration_gitlab",
    {
    "Bad HTTP method" : "Phương thức HTTP không hợp lệ",
    "Bad credentials" : "Thông tin đăng nhập không hợp lệ.",
    "Connected accounts" : "Đã kết nối tài khoản",
    "Unknown error" : "Lỗi không xác định",
    "Comments" : "Các bình luận",
    "Owner" : "Chủ",
    "Click to expand comment" : "Nhấp để mở rộng bình luận"
},
"nplurals=1; plural=0;");
