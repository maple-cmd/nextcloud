OC.L10N.register(
    "integration_gitlab",
    {
    "Bad HTTP method" : "Nederīgs HTTP pieprasījuma veids",
    "Bad credentials" : "Nederīgi pieteikšanās dati",
    "Connected accounts" : "Sasaistītie konti",
    "Account added" : "Konts pievienots",
    "Failed to add account" : "Neizdevās pievienot kontu",
    "No GitLab account connected" : "Nav sasaistītu GitLab kontu",
    "Unknown error" : "Nezināma kļūda",
    "GitLab connected accounts settings" : "Sasaistīto GitLab kontu iestatījumi",
    "Comments" : "Piebildes",
    "Owner" : "Īpašnieks"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
