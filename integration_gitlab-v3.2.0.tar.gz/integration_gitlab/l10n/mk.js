OC.L10N.register(
    "integration_gitlab",
    {
    "Error during OAuth exchanges" : "Грешка при размена на податоци за OAuth ",
    "Bad credentials" : "Неточни акредитиви",
    "OAuth access token refused" : "Одбиен OAuth пристапен токен ",
    "Connected accounts" : "Поврзани сметки",
    "Unknown error" : "Непозната грешка",
    "Comments" : "Коментари",
    "Author" : "Автор",
    "Owner" : "Сопственик"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
