OC.L10N.register(
    "integration_gitlab",
    {
    "Bad credentials" : "Marrits identificants",
    "Connected accounts" : "Comptes connectats",
    "Unknown error" : "Error desconeguda",
    "Comments" : "Comentaris",
    "Owner" : "Owner"
},
"nplurals=2; plural=(n > 1);");
