OC.L10N.register(
    "integration_gitlab",
    {
    "Error during OAuth exchanges" : "Villa í OAuth-samskiptum",
    "Bad credentials" : "Gölluð auðkenni",
    "OAuth access token refused" : "OAuth-aðgangsteikni hafnað",
    "Connected accounts" : "Tengdir aðgangar",
    "Remove account" : "Fjarlægja notandaaðgang",
    "Unknown error" : "Óþekkt villa",
    "Comments" : "Athugasemdir",
    "Author" : "Höfundur",
    "Owner" : "Eigandi",
    "Click to expand comment" : "Smelltu til að fella út athugasemd"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
