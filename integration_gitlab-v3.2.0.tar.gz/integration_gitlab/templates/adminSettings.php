<?php
$appId = OCA\Gitlab\AppInfo\Application::APP_ID;
\OCP\Util::addScript($appId, $appId . '-adminSettings');
?>

<div id="gitlab_prefs"></div>
