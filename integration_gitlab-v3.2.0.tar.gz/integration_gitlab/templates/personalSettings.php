<?php
$appId = OCA\Gitlab\AppInfo\Application::APP_ID;
\OCP\Util::addScript($appId, $appId . '-personalSettings');
?>

<div id="gitlab_prefs"></div>
