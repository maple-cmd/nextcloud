OC.L10N.register(
    "integration_onedrive",
    {
    "Client ID" : "ID del cliente",
    "Client secret" : "Secreto del cliente",
    "Contacts" : "Contactos",
    "Import calendar" : "Importar calendario"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
