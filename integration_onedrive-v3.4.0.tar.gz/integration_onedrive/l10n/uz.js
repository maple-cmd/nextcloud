OC.L10N.register(
    "integration_onedrive",
    {
    "Bad credentials" : "Akkaunt ma'lumotlari xato",
    "Bad HTTP method" : "Yomon HTTP usuli",
    "Client ID" : "Mijoz identifikatori",
    "Contacts" : "Contacts",
    "Calendars" : "Taqvimlar"
},
"nplurals=1; plural=0;");
