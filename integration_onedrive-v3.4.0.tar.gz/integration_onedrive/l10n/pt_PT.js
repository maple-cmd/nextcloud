OC.L10N.register(
    "integration_onedrive",
    {
    "Error during OAuth exchanges" : "Erro durante trocas com o OAuth",
    "Bad credentials" : "Credenciais inválidas",
    "Bad HTTP method" : "Método HTTP incorreto",
    "Client ID" : "Id. do Cliente",
    "Client secret" : "Segredo do cliente\\\\",
    "Contacts" : "Contactos",
    "Calendars" : "Calendários",
    "Import calendar" : "Importar calendário"
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
