OC.L10N.register(
    "integration_onedrive",
    {
    "Client ID" : "รหัสไคลเอ็นต์",
    "Client secret" : "ข้อมูลลับไคลเอ็นต์",
    "Connected as {user}" : "เชื่อมต่อเป็น {user} แล้ว",
    "Contacts" : "รายชื่อ",
    "Calendars" : "ปฏิทิน",
    "Import calendar" : "นำเข้าปฏิทิน"
},
"nplurals=1; plural=0;");
