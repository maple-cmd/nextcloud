OC.L10N.register(
    "integration_onedrive",
    {
    "Bad credentials" : "Marrits identificants",
    "Connected accounts" : "Comptes connectats",
    "Client ID" : "ID client",
    "Connected as {user}" : "Connectat coma {user}",
    "Contacts" : "Contactes",
    "Calendars" : "Calendièrs",
    "Import calendar" : "Importar un calendièr"
},
"nplurals=2; plural=(n > 1);");
