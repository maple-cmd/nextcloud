OC.L10N.register(
    "integration_onedrive",
    {
    "Client ID" : "კლიენტის ID",
    "Client secret" : "კლიენტის საიდუმლო",
    "Contacts" : "კონტაქტები",
    "Import calendar" : "კალენდრის იმპორტი"
},
"nplurals=2; plural=(n!=1);");
