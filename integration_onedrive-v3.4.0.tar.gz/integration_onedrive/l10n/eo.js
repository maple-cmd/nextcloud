OC.L10N.register(
    "integration_onedrive",
    {
    "Client ID" : "Klientidentigilo",
    "Client secret" : "Klientosekreto",
    "Contacts" : "Kontaktoj",
    "Import calendar" : "Enporti kalendaron"
},
"nplurals=2; plural=(n != 1);");
