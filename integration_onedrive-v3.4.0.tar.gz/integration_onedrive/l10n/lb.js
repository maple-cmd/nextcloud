OC.L10N.register(
    "integration_onedrive",
    {
    "Client ID" : "Client ID",
    "Contacts" : "Kontakter",
    "Calendars" : "Kalenneren",
    "Import calendar" : "Kalenner importéiren"
},
"nplurals=2; plural=(n != 1);");
