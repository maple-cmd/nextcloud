OC.L10N.register(
    "integration_onedrive",
    {
    "Data migration" : "Migración de los datos",
    "Client ID" : "ID de veceru",
    "Client secret" : "Secretu de veceru",
    "Failed to save OneDrive options" : "Nun se pue guardar la configuración d'OneDrive",
    "Failed to import calendar" : "Nun se pue importar el calendariu",
    "Failed to get number of contacts" : "Nun se pue consiguir el númberu de contautos",
    "Contacts" : "Contautos",
    "Calendars" : "Calendarios"
},
"nplurals=2; plural=(n != 1);");
