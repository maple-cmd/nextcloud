OC.L10N.register(
    "integration_onedrive",
    {
    "Client ID" : "ID klienti",
    "Client secret" : "E fshehtë klienti",
    "Contacts" : "Kontaktet",
    "Import calendar" : "Importo kalendar"
},
"nplurals=2; plural=(n != 1);");
