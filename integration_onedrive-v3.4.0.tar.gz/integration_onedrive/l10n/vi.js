OC.L10N.register(
    "integration_onedrive",
    {
    "Bad credentials" : "Thông tin đăng nhập không hợp lệ.",
    "Bad HTTP method" : "Phương thức HTTP không hợp lệ",
    "Connected accounts" : "Đã kết nối tài khoản",
    "Client ID" : "ID khách hàng",
    "Connected as {user}" : "Kết nối bởi {user}",
    "Contacts" : "Danh bạ",
    "Calendars" : "Lịch",
    "Import calendar" : "Nhập lịch biểu"
},
"nplurals=1; plural=0;");
