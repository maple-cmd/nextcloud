OC.L10N.register(
    "integration_onedrive",
    {
    "Client ID" : "Client ID",
    "Client secret" : "Client secret",
    "Contacts" : "Contacts",
    "Calendars" : "Calendars",
    "Import calendar" : "Import calendar"
},
"nplurals=2; plural=(n!=1);");
