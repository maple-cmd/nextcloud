OC.L10N.register(
    "integration_onedrive",
    {
    "Bad credentials" : "Vale kasutajanimi, salasõna või tunnusluba",
    "Bad HTTP method" : "Vigane HTTP-meetod",
    "Connected accounts" : "Ühendatud kasutajakontod",
    "Client ID" : "Kliendi ID",
    "Client secret" : "Kliendi salasõna",
    "Connected as {user}" : "Ühendatud kui {user}",
    "Contacts" : "Kontaktid",
    "Calendars" : "Kalendrid",
    "Import calendar" : "Impordi kalender"
},
"nplurals=2; plural=(n != 1);");
