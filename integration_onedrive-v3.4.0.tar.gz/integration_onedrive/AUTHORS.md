<!--
  - SPDX-FileCopyrightText: 2020 Nextcloud GmbH and Nextcloud contributors
  - SPDX-License-Identifier: CC0-1.0
-->
# Authors

* Julien Veyssier <eneiluj@posteo.net> (Developper)
* Marcel Klehr <mklehr@gmx.net> (maintainer)
* Alexander Piskun <bigcat88@icloud.com> (maintainer)
