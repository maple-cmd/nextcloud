<?php

declare(strict_types=1);

namespace OCA\SocialLogin\Controller;

use OCA\SocialLogin\Db\ConnectedLoginMapper;
use OCP\AppFramework\Http\Attribute\PasswordConfirmationRequired;
use OCP\AppFramework\Http\DataResponse;
use OCP\AppFramework\OCSController;
use OCP\IRequest;

class LinkController extends OCSController
{
    /** @var ConnectedLoginMapper */
    private $socialConnect;

    public function __construct(
        $appName,
        IRequest $request,
        ConnectedLoginMapper $socialConnect
    ) {
        parent::__construct($appName, $request);
        $this->socialConnect = $socialConnect;
    }

    /**
     * @PasswordConfirmationRequired
     * @param string $uid
     * @param string $identifier
     * @return DataResponse
     */
    #[PasswordConfirmationRequired]
    public function connectSocialLogin($uid, $identifier): DataResponse
    {
        $this->socialConnect->connectLogin($uid, $identifier);
        return new DataResponse();
    }

    /**
     * @PasswordConfirmationRequired
     * @param string $identifier
     * @return DataResponse
     */
    #[PasswordConfirmationRequired]
    public function disconnectSocialLogin($identifier): DataResponse
    {
        $this->socialConnect->disconnectLogin($identifier);
        return new DataResponse();
    }
}
