OC.L10N.register(
    "sociallogin",
    {
    "Log in with username or email" : "Log ind med brugernavn eller e-mail",
    "Log in with %s" : "Log på med %s",
    "This account already connected" : "Denne konto er allerede blevet forbundet",
    "Auto creating new users is disabled" : "Automatisk oprettelse af nye brugere er slået fra",
    "Email already registered" : "E-mail adressen er allerede i brug",
    "New user created" : "Ny bruger oprettet",
    "Save" : "Gem",
    "None" : "Ingen",
    "Secret" : "Hemmelighed",
    "Automatically create groups if they do not exists" : "Opret automatisk grupper hvis de ikke eksisterer",
    "Hide default login" : "Skjul standard login",
    "Title" : "Titel",
    "Token url" : "Token url",
    "Client Id" : "Klient ID",
    "Client Secret" : "Klient-Secret",
    "Scope" : "Anvendelsesområde"
},
"nplurals=2; plural=(n != 1);");
