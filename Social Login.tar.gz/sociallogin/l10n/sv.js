OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Spara",
    "None" : "Ingen",
    "Team ID" : "Team-ID",
    "Secret" : "Hemlig",
    "Title" : "Titel",
    "Client Secret" : "Klienthemlighet",
    "Scope" : "Sammanhang",
    "Consumer key" : "Konsumentnyckel"
},
"nplurals=2; plural=(n != 1);");
