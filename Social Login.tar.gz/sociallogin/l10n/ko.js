OC.L10N.register(
    "sociallogin",
    {
    "Log in with username or email" : "아이디 또는 이메일로 로그인",
    "This account already connected" : "이 계정은 이미 연결됨",
    "Save" : "저장",
    "None" : "없음",
    "Team ID" : "팀 아이디",
    "Secret" : "비밀",
    "Title" : "제목",
    "Client Secret" : "클라이언트 비밀 값",
    "Scope" : "범위"
},
"nplurals=1; plural=0;");
