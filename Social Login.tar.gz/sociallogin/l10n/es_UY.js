OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Guardar",
    "None" : "Ninguno",
    "Secret" : "Secreto",
    "Title" : "Título",
    "Scope" : "Alcance"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
