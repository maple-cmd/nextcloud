OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Desa",
    "None" : "Només una vegada",
    "Team ID" : "ID de l'equip",
    "Secret" : "Secret",
    "Title" : "Títol",
    "Client Secret" : "Secret del client",
    "Scope" : "Abast",
    "Consumer key" : "Clau del client"
},
"nplurals=2; plural=(n != 1);");
