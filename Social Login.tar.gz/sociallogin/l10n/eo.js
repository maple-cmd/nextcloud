OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Konservi",
    "None" : "Nenio",
    "Secret" : "Sekreta",
    "Title" : "Titolo",
    "Scope" : "Amplekso"
},
"nplurals=2; plural=(n != 1);");
