OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Захаваць",
    "None" : "Няма",
    "Team ID" : "Ідэнтыфікатар каманды",
    "Title" : "Загаловак",
    "Token url" : "URL-адрас токена",
    "Display name claim (optional)" : "Заява на імя для паказу (неабавязкова)",
    "Token url (can be relative to base URL)" : "URL-адрас токена (можа быць адносным да базавага URL-адраса)"
},
"nplurals=4; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<12 || n%100>14) ? 1 : n%10==0 || (n%10>=5 && n%10<=9) || (n%100>=11 && n%100<=14)? 2 : 3);");
