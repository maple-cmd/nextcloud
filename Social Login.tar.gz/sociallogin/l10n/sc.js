OC.L10N.register(
    "sociallogin",
    {
    "Save" : "Sarva",
    "None" : "Perunu",
    "Team ID" : "ID de grupu",
    "Secret" : "Segretu",
    "Allow login only for specified workspace" : "Permite s'identificatzione isceti pro s'ispàtziu de traballu ispetzificadu",
    "Title" : "Tìtulu",
    "Client Secret" : "Segretu de su cliente",
    "Scope" : "Àmbitu",
    "Consumer key" : "Crae cliente"
},
"nplurals=2; plural=(n != 1);");
