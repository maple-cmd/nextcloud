<?php

namespace HybridauthTest\Hybridauth;

use Hybridauth\Hybridauth;

class HybridauthTest extends \PHPUnit\Framework\TestCase
{
    public function test_pass()
    {
        $this->assertTrue(true);
    }
}
