## Bug, feature or question?

Is this a bug, a feature request or a question?
Give us a short description.

### Version and provider

What version of Hybrid Auth does this relates to?
Is this an issue with a provider? If yes, which one?

### Reproduction

How can we replicate this issue?
